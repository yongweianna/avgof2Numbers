package com.example.averageof2no;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
  private EditText editText1;
  private EditText editText2;
  private TextView textViewResult;
  private Button buttonadd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText1 = findViewById(R.id.edittext_no1);
        editText2 = findViewById(R.id.edittext_no2);
        textViewResult= findViewById(R.id.textview_result);
        buttonadd = findViewById(R.id.button_plus);

        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                if(editText1.getText().toString().length() == 0){
                    editText1.setText("0");
                }
                int num1 = Integer.parseInt(editText1.getText().toString());
                int num2 = Integer.parseInt(editText2.getText().toString());
                int avg = (num1 + num2)/2;
                textViewResult.setText(Integer.toString(avg));
            }
        });
    }
}